# backend/services/radar_service/main.py
import subprocess
import time
import os
import sys
import asyncio
from dataclasses import dataclass, field
from typing import Optional

BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT_ROOT = os.path.dirname(BACKEND_DIR)

CRAWLER_DIR = os.path.join(BACKEND_DIR, "services", "crawler_service")

# venv Python 解释器路径，确保子进程与当前环境一致
VENV_PYTHON = os.path.join(PROJECT_ROOT, "venv", "Scripts", "python.exe")
if not os.path.exists(VENV_PYTHON):
    VENV_PYTHON = sys.executable  # 回退到当前解释器

from backend.core.logger import get_logger
from backend.core.context import set_task_context

logger = get_logger("radar.main")
from backend.core.config import settings
from .db import get_unprocessed_posts, mark_processed_batch, save_ai_result, get_aggregated_keywords, get_aggregated_platforms
from .schemas import ScreenerResult
from .notifier import send_alert
from .pipeline import RadarPipeline, PipelineConfig

MONITOR_KEYWORDS = []
MONITOR_PLATFORMS = []
ALERT_NEGATIVE = True
MONITOR_KEYWORD_LEVELS = {}


@dataclass
class RadarStatus:
    """线程安全的雷达状态（兼容同步/异步读写）"""
    is_running: bool = False
    status_text: str = "系统闲置中"
    last_run_time: str = "暂无"
    last_new_count: int = 0
    _lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    async def set_running(self, text: str):
        async with self._lock:
            self.is_running = True
            self.status_text = text
            self.last_new_count = 0

    async def set_idle(self, text: str = "系统闲置中"):
        async with self._lock:
            self.is_running = False
            self.status_text = text

    async def is_busy(self) -> bool:
        async with self._lock:
            return self.is_running

    # 同步写入方法（供 tools.py 这类同步模块使用）
    def set_running_sync(self, text: str):
        self.is_running = True
        self.status_text = text
        self.last_new_count = 0

    def set_idle_sync(self, text: str = "系统闲置中"):
        self.is_running = False
        self.status_text = text

    def set_result_sync(self, new_count: int, run_time: str):
        self.last_new_count = new_count
        self.last_run_time = run_time

    def get_status_dict(self) -> dict:
        """返回当前状态的 dict 快照（同步读取）"""
        return {
            "is_running": self.is_running,
            "status_text": self.status_text,
            "last_run_time": self.last_run_time,
            "last_new_count": self.last_new_count,
        }


# 全局实例（backward compat，owner_id=None）
radar_status = RadarStatus()

# v2.2 per-user radar status
_user_radar_statuses: dict[str, RadarStatus] = {}

def get_radar_status(owner_id: Optional[str] = None) -> RadarStatus:
    """返回指定用户的雷达状态，owner_id=None 返回全局实例（backward compat）"""
    if owner_id is None:
        return radar_status
    if owner_id not in _user_radar_statuses:
        _user_radar_statuses[owner_id] = RadarStatus()
    return _user_radar_statuses[owner_id]

def reload_config():
    global MONITOR_KEYWORDS, MONITOR_KEYWORD_LEVELS, MONITOR_PLATFORMS, ALERT_NEGATIVE
    try:
        keywords = get_aggregated_keywords()
        platforms = get_aggregated_platforms()
    except Exception:
        keywords, platforms = [], []

    MONITOR_KEYWORDS = keywords
    MONITOR_KEYWORD_LEVELS = {kw: "balanced" for kw in keywords}
    MONITOR_PLATFORMS = platforms
    ALERT_NEGATIVE = True
    logger.info(f"Loaded aggregated config: keywords={MONITOR_KEYWORDS}, platforms={MONITOR_PLATFORMS}")

def run_crawler_for_platform(platform):
    logger.info(f"Starting crawler for platform: {platform.upper()}")
    try:
        # clean_env = os.environ.copy()
        # if "VIRTUAL_ENV" in clean_env:
        #     del clean_env["VIRTUAL_ENV"]
            
        if not MONITOR_KEYWORDS:
            logger.warning("No keywords specified, skipping task.")
            return
            
        keywords_str = ",".join(MONITOR_KEYWORDS)
        logger.info(f"Executing task with keywords: {keywords_str}")
        
        if not os.path.exists(CRAWLER_DIR):
            logger.error(f"【致命错误】找不到爬虫目录: {CRAWLER_DIR}")
            return

        subprocess.run(
            [
                VENV_PYTHON, "main.py", 
                "--platform", platform, 
                "--type", "search", 
                "--save_data_option", "sqlite", 
                "--headless", "no",
                "--keywords", keywords_str
            ],
            cwd=CRAWLER_DIR, 
            # env=clean_env, 
            check=True,
            timeout=600 
        )
        logger.info(f"{platform.upper()} data extraction completed.")
    except subprocess.TimeoutExpired:
        logger.error(f"Task timeout for platform {platform}, terminated forcefully.")
    except subprocess.CalledProcessError as e:
        logger.error(f"Execution failed for platform {platform}: {e}")

async def run_crawler_for_platform_async(platform: str):
    """异步执行爬虫，不阻塞事件循环"""
    global MONITOR_KEYWORDS
    if not MONITOR_KEYWORDS:
        logger.warning("No keywords specified, skipping.")
        return

    keywords_str = ",".join(MONITOR_KEYWORDS)
    logger.info(f"[Async Crawler] Starting {platform.upper()}... (python={VENV_PYTHON})")
    logger.info(f"[Async Crawler] cwd={CRAWLER_DIR}, exists={os.path.exists(CRAWLER_DIR)}")

    if not os.path.exists(VENV_PYTHON):
        logger.error(f"[Async Crawler] Python interpreter not found: {VENV_PYTHON}")
        return

    import platform as sys_platform
    creation_flags = 0
    if sys_platform.system() == "Windows":
        creation_flags = subprocess.CREATE_NO_WINDOW

    process = await asyncio.create_subprocess_exec(
        VENV_PYTHON, "main.py",
        "--platform", platform,
        "--type", "search",
        "--save_data_option", "sqlite",
        "--headless", "no",
        "--keywords", keywords_str,
        cwd=CRAWLER_DIR,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        creationflags=creation_flags,
    )
    try:
        stdout_data, stderr_data = await asyncio.wait_for(process.communicate(), timeout=600)
        output = stdout_data.decode("utf-8", errors="replace") if stdout_data else ""
        err_output = stderr_data.decode("utf-8", errors="replace") if stderr_data else ""
        if output:
            for line in output.splitlines()[:30]:
                logger.info(f"[Crawler stdout] {line}")
        if err_output:
            for line in err_output.splitlines()[:30]:
                logger.warning(f"[Crawler stderr] {line}")
        if not output and not err_output:
            logger.warning(f"[Async Crawler] No output, returncode={process.returncode}")
        logger.info(f"[Async Crawler] {platform.upper()} done, returncode={process.returncode}")
    except asyncio.TimeoutError:
        process.kill()
        logger.error(f"[Async Crawler] {platform.upper()} timeout.")

async def job_async(target_keyword: str = None, owner_id: Optional[str] = None):
    """雷达核心任务流（异步版）
    WS4.6：owner_id 标识本次扫描的归属用户（None 表示公共/历史扫描）
    """
    global MONITOR_KEYWORDS, MONITOR_KEYWORD_LEVELS
    reload_config()
    if target_keyword:
        MONITOR_KEYWORDS = [target_keyword]
        MONITOR_KEYWORD_LEVELS = {target_keyword: "balanced"}

    if MONITOR_PLATFORMS:
        await asyncio.gather(*[
            run_crawler_for_platform_async(p) for p in MONITOR_PLATFORMS
        ], return_exceptions=True)
    else:
        logger.warning("MONITOR_PLATFORMS 为空，跳过。")

    new_risk_count = await run_analysis_pipeline_async(owner_id=owner_id)

    # 更新雷达状态（per-user）
    st = get_radar_status(owner_id)
    st.last_new_count = new_risk_count if new_risk_count else 0
    st.last_run_time = time.strftime('%Y-%m-%d %H:%M:%S')

    return new_risk_count

async def run_analysis_pipeline_async(owner_id: Optional[str] = None):
    """使用 RadarPipeline 执行完整分析流程（多平台 asyncio 并行）。
    WS4.6：owner_id 透传到 save_ai_result / create_or_update_topic_summary
    """
    import asyncio

    async def _run_single_platform(platform: str) -> int:
        """单个平台的完整 Pipeline（抓取 → 分析 → 持久化）。"""
        logger.info(f"[Pipeline Mode] Analyzing {platform.upper()}...")
        posts = get_unprocessed_posts(settings.CRAWLER_DB_PATH, platform)
        if not posts:
            return 0

        all_post_ids = [p["post_id"] for p in posts]

        config = PipelineConfig(
            keywords=MONITOR_KEYWORDS,
            keyword_levels=MONITOR_KEYWORD_LEVELS,
            platform=platform,
            alert_negative=ALERT_NEGATIVE,
            owner_id=owner_id,
            mode="full",  # 定时扫描：完整链路（含 LangGraph 分析 + 预警）
        )
        pipeline = RadarPipeline(config)
        results = await pipeline.run(posts)

        # 批量标记已处理
        if all_post_ids:
            processed_records = [(pid, platform) for pid in all_post_ids]
            mark_processed_batch(processed_records)

        # 保存结果入库（WS4.6：传入 owner_id / P1 Fix：to_thread 避免阻塞事件循环）
        new_count = 0
        for pr in results:
            await asyncio.to_thread(
                save_ai_result,
                post_id=pr.post_id,
                platform=pr.platform,
                keyword=pr.keyword,
                title=pr.title,
                content=pr.content,
                url=pr.url,
                risk_level=pr.risk_level,
                core_issue=pr.core_issue,
                report=pr.report,
                publish_time=pr.publish_time,
                sentiment=getattr(pr, 'sentiment', 'Neutral'),
                owner_id=owner_id,
            )
            new_count += 1
        return new_count

    # 所有平台并发（各平台独立运行，无依赖）
    tasks = [
        _run_single_platform(platform)
        for platform in MONITOR_PLATFORMS
    ]
    all_results = await asyncio.gather(*tasks, return_exceptions=True)

    # 汇总结果（过滤异常）
    total_new_count = 0
    for i, result in enumerate(all_results):
        platform = MONITOR_PLATFORMS[i]
        if isinstance(result, Exception):
            logger.error(f"平台 {platform} 执行异常: {result}")
        else:
            total_new_count += result
            logger.info(f"[Pipeline Mode] {platform.upper()} 完成，新增 {result} 条")

    return total_new_count


def run_analysis_pipeline(owner_id: Optional[str] = None):
    """同步入口（WS4.6：带 owner_id）"""
    import asyncio
    return asyncio.run(run_analysis_pipeline_async(owner_id=owner_id))


def api_start_task(background_tasks, owner_id: Optional[str] = None):
    # 检查调度器全局锁
    try:
        from .scheduler import _scan_lock
        if _scan_lock.locked():
            return False, "定时扫描任务正在运行中，请稍后再试"
    except Exception:
        pass

    status = get_radar_status(owner_id)
    if status.is_running:
        return False, "扫描任务正在运行中，请勿重复启动"

    reload_config()
    current_keyword = "、".join(MONITOR_KEYWORDS)

    def _run_in_background():
        nonlocal status
        status.set_running_sync(f"正在监控: {current_keyword}")
        try:
            new_count = job(owner_id=owner_id)
            status.last_new_count = new_count if new_count else 0
            status.last_run_time = time.strftime('%Y-%m-%d %H:%M:%S')
        except Exception as e:
            logger.error(f"Background task exception: {e}")
            status.last_new_count = 0
        finally:
            status.set_idle_sync()

    background_tasks.add_task(_run_in_background)
    return True, "扫描任务已启动"

def job(target_keyword=None, owner_id: Optional[str] = None):
    """
    雷达核心任务流
    :param target_keyword: 如果指定了该关键字，本次爬虫和分析将只针对该词进行（用于 Agent 动态触发）
    :param owner_id: WS4.6 数据归属（None=公共/历史）
    """
    logger.info(f"Starting radar job pipeline (target_keyword={target_keyword}, owner_id={owner_id})")

    reload_config()

    if target_keyword:
        global MONITOR_KEYWORDS, MONITOR_KEYWORD_LEVELS
        MONITOR_KEYWORDS = [target_keyword]
        MONITOR_KEYWORD_LEVELS = {target_keyword: "balanced"} # 临时任务默认给予 balanced 敏感度
        logger.info(f"临时接管监控配置，本次将专注抓取: {target_keyword}")

    if MONITOR_PLATFORMS:
        for platform in MONITOR_PLATFORMS:
            run_crawler_for_platform(platform)
    else:
        logger.warning("MONITOR_PLATFORMS 为空，请检查系统设置！爬虫任务被跳过。")

    new_risk_count = run_analysis_pipeline(owner_id=owner_id)
    return new_risk_count